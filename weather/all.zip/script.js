var button = document.querySelector('.button')
var placevalue = document.querySelector('.placevalue')

var name = document.querySelector('.placename');
var desc = document.querySelector('.desc');
var temp = document.querySelector('.temp');


button.addEventListener('click', function() {

    fetch('https://api.openweathermap.org/data/2.5/weather?q='+placevalue.value+'&appid=afa43f24242d8b9eb3d96d4616ec9ec8')
    .then(response => response.json())
    .then(data => {
        var namevalue = data['name'];
        var descvalue = data['main']['temp'];
        var tempvalue = data['weather'][0]['description'];

        placename.innerHTML = namevalue;
        desc.innerHTML = descvalue;
        temp.innerHTML = tempvalue;
    })
    

    .catch(err => alert("entered wrong city name please type again"))
})

